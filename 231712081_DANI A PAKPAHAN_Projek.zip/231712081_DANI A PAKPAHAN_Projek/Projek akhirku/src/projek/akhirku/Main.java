package projek.akhirku;

public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        Jframe inJframe = new Jframe();
        inJframe.setVisible(true);
    }
    
}
